import 'package:flutter/material.dart';
import 'services/joke_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final service = JokeService();

  final joke = await service.fetchRandomJoke();
  print('${joke.setup} / ${joke.punchline}');

  final jokes = await service.fetchTenJokes();
  print('Got ${jokes.length} jokes');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(title),
      ),
      body: const Center(
        child: Text('Flutter API Demo'),
      ),
    );
  }
}